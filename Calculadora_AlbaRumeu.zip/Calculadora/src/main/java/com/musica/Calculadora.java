package com.musica;

import java.util.Scanner;
/**
 * Clase que implementa una calculadora con las operaciones de suma, resta, multiplicación y división.
 * @author Alba Rumeu.
 * @version 1
 */
public class Calculadora {
    /**
     * Metodo principal
     * */
    public static void main(String[] args) {
        Calculadora calc = new Calculadora();
        Scanner scanner = new Scanner(System.in);
        String nombre = "Alba";

        System.out.println(" Bienvenido a la Calculadora de " + nombre);
        System.out.print("Introduce la operación (sumar, restar, multiplicar, dividir): ");
        String operador = scanner.nextLine();

        System.out.print("Introduce el primer número: ");
        int a = scanner.nextInt();

        System.out.print("Introduce el segundo número: ");
        int b = scanner.nextInt();
        System.out.println("Iniciamos Operacion: ");

        try {
            int resultado = calc.operar(operador, a, b);
            System.out.println(" Resultado: " + resultado);
        } catch (Exception e) {
            System.out.println("️ Error: " + e.getMessage());
        }
        // Cerramos scanner
        scanner.close();
    }
    /**
     * Hace la operacion indicada entre los numero asignados como a y b
     * @param operador El tipo de operacion que queremos hacer ( sumar, restar, multiplicar, dividir )
     * @param a Primer número.
     * @param b Segundo número.
     * @return Resultado de la operación.
     * @throws ArithmeticException será por si se intenta dividir entre 0
     */

    public int operar(String operador, int a, int b) {
        // Iniciamos primer if
        if (operador.equals("sumar")) {
            int resultado = a + b;
            System.out.println("Resultado Suma: " + resultado);
            return resultado ;
        } else if (operador.equals("restar")) {
            int resultado = a - b;
            System.out.println("Resultado Resta: " + resultado);
            return resultado;
        } else if (operador.equals("multiplicar")) {
            int resultado = a * b;
            System.out.println("Resultado Multiplicación: " + resultado);
            return resultado;
        } else if (operador.equals("dividir")) {
            // Para mostrar error de dividir por 0
            if (b == 0) {
                throw new ArithmeticException("División por cero");
            }
            int resultado = a / b;
            System.out.println("Resultado División: " + resultado);
            return resultado;
        } else {
            System.out.println("⚠️ Error: Operación no válida");
            return 0;
        }
    }

}
