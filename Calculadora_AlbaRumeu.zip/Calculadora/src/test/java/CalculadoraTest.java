import com.musica.Calculadora;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CalculadoraTest {
    Calculadora calculadora = new Calculadora();

    @Test
    void testSumar() {
        assertEquals(15, calculadora.operar("sumar", 10, 5));
    }

    @Test
    void testRestar() {
        assertEquals(5, calculadora.operar("restar", 10, 5));
    }

    @Test
    void testMultiplicar() {
        assertEquals(10, calculadora.operar("multiplicar", 5, 2));
    }

    @Test
    void testDividir() {
        assertEquals(4, calculadora.operar("dividir", 20, 5));
    }

    @Test
    void testDividirPorCero() {
        // comento porque no se terminarla
        // ArithmeticException exception = assertThrows(ArithmeticException)

    }

}


